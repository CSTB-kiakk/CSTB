@extends('layouts.app')

@section('title', $title)

@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-heart me-3"></i>Rólunk
                </h1>
                <p class="lead">{{ $mission }}</p>
            </div>
        </div>
    </div>
</section>

<!-- Mission Section -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="fw-bold mb-4">Miért létezünk?</h2>
                <p class="lead text-muted mb-5">
                    A HazaHozLak platform célja, hogy minden állatnak megtalálja a tökéletes otthonát. 
                    Összekötjük a menhelyeket és a potenciális örökbefogadókat, hogy minden állatnak 
                    esélye legyen egy szerető családban élni.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h2 class="fw-bold">Eredményeink</h2>
                <p class="text-muted">Büszkék vagyunk a munkánk eredményeire</p>
            </div>
        </div>
        <div class="row">
            @foreach($stats as $label => $value)
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="stat-item">
                    <div class="stat-number">{{ $value }}</div>
                    <div class="text-muted">{{ $label }}</div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<!-- Values Section -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h2 class="fw-bold">Értékeink</h2>
                <p class="text-muted">Ezek vezérlik a munkánkat minden nap</p>
            </div>
        </div>
        <div class="row">
            @foreach($values as $title => $description)
            <div class="col-lg-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-primary">{{ $title }}</h5>
                        <p class="card-text">{{ $description }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h2 class="fw-bold">Hogyan működik?</h2>
                <p class="text-muted">Néhány egyszerű lépésben megtalálhatod a tökéletes társat</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="text-center">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 80px; height: 80px;">
                        <i class="fas fa-search fa-2x"></i>
                    </div>
                    <h5 class="fw-bold">1. Böngészd az állatokat</h5>
                    <p class="text-muted">Nézd meg a kategóriákat és találd meg a számodra megfelelő állatot</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 80px; height: 80px;">
                        <i class="fas fa-heart fa-2x"></i>
                    </div>
                    <h5 class="fw-bold">2. Jelöld ki a kedvenceket</h5>
                    <p class="text-muted">Mentsd el a szívedre húzott állatokat és kövesd nyomon az állapotukat</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 80px; height: 80px;">
                        <i class="fas fa-home fa-2x"></i>
                    </div>
                    <h5 class="fw-bold">3. Örökbefogadás</h5>
                    <p class="text-muted">Jelentkezz az örökbefogadásra és hozd haza az új családtagot</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2 class="fw-bold mb-4">Készen állsz a kezdésre?</h2>
                <p class="lead mb-4">Csatlakozz hozzánk és segíts minden állatnak megtalálni a szerető otthonát!</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="{{ route('animals.index') }}" class="btn btn-primary btn-lg">
                        <i class="fas fa-search me-2"></i>Állataink böngészése
                    </a>
                    <a href="{{ route('contact') }}" class="btn btn-outline-primary btn-lg">
                        <i class="fas fa-envelope me-2"></i>Kapcsolat
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
