@extends('layouts.app')

@section('title', $title)

@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-envelope me-3"></i>Kapcsolat
                </h1>
                <p class="lead">Ha bármilyen kérdésed van, keress minket bizalommal!</p>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- Contact Info -->
            <div class="col-lg-4 mb-5">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">
                            <i class="fas fa-info-circle text-primary me-2"></i>Elérhetőségek
                        </h3>
                        <div class="mb-3">
                            <i class="fas fa-envelope text-primary me-2"></i>
                            <strong>Email:</strong> {{ $contact_info['email'] }}
                        </div>
                        <div class="mb-3">
                            <i class="fas fa-phone text-primary me-2"></i>
                            <strong>Telefon:</strong> {{ $contact_info['phone'] }}
                        </div>
                        <div class="mb-4">
                            <i class="fas fa-map-marker-alt text-primary me-2"></i>
                            <strong>Cím:</strong> {{ $contact_info['address'] }}
                        </div>
                        
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-clock text-primary me-2"></i>Nyitvatartás
                        </h5>
                        @foreach($opening_hours as $day => $hours)
                            <div class="d-flex justify-content-between mb-2">
                                <span><strong>{{ $day }}:</strong></span>
                                <span>{{ $hours }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">
                            <i class="fas fa-paper-plane text-primary me-2"></i>Küldj üzenetet
                        </h3>
                        
                        <form method="POST" action="{{ route('contact.send') }}">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Név *</label>
                                    <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                           id="name" name="name" value="{{ old('name') }}" required>
                                    @error('name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                           id="email" name="email" value="{{ old('email') }}" required>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Üzenet *</label>
                                <textarea class="form-control @error('message') is-invalid @enderror" 
                                          id="message" name="message" rows="5" required 
                                          placeholder="Írd ide az üzeneted...">{{ old('message') }}</textarea>
                                @error('message')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i>Üzenet küldése
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shelters Section -->
        @if($shelters->count() > 0)
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="fw-bold mb-4 text-center">
                    <i class="fas fa-home text-primary me-2"></i>Partnereink menhelyek
                </h3>
                <div class="row">
                    @foreach($shelters as $shelter)
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title fw-bold">{{ $shelter->name }}</h5>
                                <p class="card-text">
                                    <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                    {{ $shelter->location }}
                                </p>
                                <p class="card-text">
                                    <i class="fas fa-envelope text-primary me-2"></i>
                                    {{ $shelter->contact_email }}
                                </p>
                                @if($shelter->description)
                                    <p class="card-text">{{ Str::limit($shelter->description, 100) }}</p>
                                @endif
                                <div class="mt-auto">
                                    <a href="mailto:{{ $shelter->contact_email }}" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-envelope me-1"></i>Email küldése
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>
</section>
@endsection
