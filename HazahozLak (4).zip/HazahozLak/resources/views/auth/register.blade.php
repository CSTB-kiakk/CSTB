@extends('layouts.app')

@section('title', 'Regisztráció - HazaHozLak')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-plus text-primary" style="font-size: 3rem;"></i>
                        <h2 class="fw-bold mt-3">Regisztráció</h2>
                        <p class="text-muted">Válaszd ki a regisztráció típusát</p>
                    </div>

                    <!-- Regisztráció típus választó -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card registration-type-card" data-type="adopter">
                                <div class="card-body text-center p-4">
                                    <i class="fas fa-heart text-primary mb-3" style="font-size: 2.5rem;"></i>
                                    <h5 class="fw-bold">Örökbefogadó</h5>
                                    <p class="text-muted small">Személyes fiók állatok örökbefogadásához</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card registration-type-card" data-type="shelter">
                                <div class="card-body text-center p-4">
                                    <i class="fas fa-home text-primary mb-3" style="font-size: 2.5rem;"></i>
                                    <h5 class="fw-bold">Menhely</h5>
                                    <p class="text-muted small">Menhely fiók állatok feltöltéséhez</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Örökbefogadó regisztrációs form -->
                    <form method="POST" action="{{ route('register') }}" id="adopter-form" style="display: none;">
                        @csrf
                        <input type="hidden" name="user_type" value="adopter">
                        
                        <h4 class="fw-bold mb-4 text-center">
                            <i class="fas fa-heart text-primary me-2"></i>Örökbefogadó regisztráció
                        </h4>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="adopter_firstname" class="form-label">Keresztnév</label>
                                <input type="text" class="form-control @error('firstname') is-invalid @enderror" 
                                       id="adopter_firstname" name="firstname" value="{{ old('firstname') }}">
                                @error('firstname')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="adopter_lastname" class="form-label">Vezetéknév</label>
                                <input type="text" class="form-control @error('lastname') is-invalid @enderror" 
                                       id="adopter_lastname" name="lastname" value="{{ old('lastname') }}">
                                @error('lastname')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="adopter_email" class="form-label">Email cím</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                   id="adopter_email" name="email" value="{{ old('email') }}">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="adopter_password" class="form-label">Jelszó</label>
                            <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                   id="adopter_password" name="password">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="adopter_password_confirmation" class="form-label">Jelszó megerősítése</label>
                            <input type="password" class="form-control" 
                                   id="adopter_password_confirmation" name="password_confirmation">
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="adopter_terms" required>
                            <label class="form-check-label" for="adopter_terms">
                                Elfogadom a <a href="#" class="text-primary">felhasználási feltételeket</a>
                            </label>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-user-plus me-2"></i>Örökbefogadó regisztráció
                            </button>
                        </div>
                    </form>

                    <!-- Menhely regisztrációs form -->
                    <form method="POST" action="{{ route('register') }}" id="shelter-form" style="display: none;">
                        @csrf
                        <input type="hidden" name="user_type" value="shelter">
                        
                        <h4 class="fw-bold mb-4 text-center">
                            <i class="fas fa-home text-primary me-2"></i>Menhely regisztráció
                        </h4>
                        
                        <div class="mb-3">
                            <label for="shelter_name" class="form-label">Menhely neve</label>
                            <input type="text" class="form-control @error('shelter_name') is-invalid @enderror" 
                                   id="shelter_name" name="shelter_name" value="{{ old('shelter_name') }}">
                            @error('shelter_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="shelter_location" class="form-label">Helyszín</label>
                            <input type="text" class="form-control @error('location') is-invalid @enderror" 
                                   id="shelter_location" name="location" value="{{ old('location') }}" 
                                   placeholder="pl. 7400 Kaposvár, Valami utca 3">
                            @error('location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="shelter_description" class="form-label">Menhely leírása</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" 
                                      id="shelter_description" name="description" rows="4" 
                                      placeholder="Írj rövid leírást a menhelyről...">{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="shelter_email" class="form-label">Bejelentkezési email cím</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                   id="shelter_email" name="email" value="{{ old('email') }}" 
                                   placeholder="Ez az email címed a bejelentkezéshez">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="form-text text-muted">Ezzel az email címmel tudsz bejelentkezni a rendszerbe</small>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_contact_email" class="form-label">Kapcsolattartási email cím</label>
                            <input type="email" class="form-control @error('contact_email') is-invalid @enderror" 
                                   id="shelter_contact_email" name="contact_email" value="{{ old('contact_email') }}" 
                                   placeholder="Ide fognak érkezni az örökbefogadási kérelmek">
                            @error('contact_email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="form-text text-muted">Ide fognak érkezni az örökbefogadási kérelmek és egyéb kapcsolattartás</small>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_password" class="form-label">Jelszó</label>
                            <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                   id="shelter_password" name="password">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="shelter_password_confirmation" class="form-label">Jelszó megerősítése</label>
                            <input type="password" class="form-control" 
                                   id="shelter_password_confirmation" name="password_confirmation">
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="shelter_terms" required>
                            <label class="form-check-label" for="shelter_terms">
                                Elfogadom a <a href="#" class="text-primary">felhasználási feltételeket</a>
                            </label>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-home me-2"></i>Menhely regisztráció
                            </button>
                        </div>
                    </form>

                    <div class="text-center mt-4">
                        <p class="text-muted">Már van fiókod? 
                            <a href="{{ route('login') }}" class="text-primary fw-bold">Jelentkezz be!</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const typeCards = document.querySelectorAll('.registration-type-card');
    const adopterForm = document.getElementById('adopter-form');
    const shelterForm = document.getElementById('shelter-form');
    
    typeCards.forEach(card => {
        card.addEventListener('click', function() {
            // Remove active class from all cards
            typeCards.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked card
            this.classList.add('active');
            
            const type = this.dataset.type;
            
            // Show/hide forms
            if (type === 'adopter') {
                adopterForm.style.display = 'block';
                shelterForm.style.display = 'none';
            } else {
                adopterForm.style.display = 'none';
                shelterForm.style.display = 'block';
            }
        });
    });
    
    // Set default selection
    typeCards[0].click();
});
</script>
@endsection

@section('styles')
<style>
.registration-type-card {
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.registration-type-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    border-color: #3b82f6;
}

.registration-type-card.active {
    border-color: #3b82f6;
    background-color: #f8fafc;
}

.registration-type-card.active .text-primary {
    color: #3b82f6 !important;
}
</style>
@endsection