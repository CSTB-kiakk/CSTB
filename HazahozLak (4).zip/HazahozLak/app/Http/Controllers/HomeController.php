<?php

namespace App\Http\Controllers;

use App\Models\Animal;
use App\Models\Species;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Főoldal megjelenítése
     */
    public function index()
    {
        // Legutóbbi 6 állat lekérése a slider-hez
        $featured_animals = Animal::with(['species', 'breed', 'shelter'])
            ->where('status', 'Available')
            ->take(6)
            ->get();

        // Összes faj lekérése a kategóriákhoz
        $species = Species::withCount('animals')->get();

        $data = [
            'title' => 'HazaHozLak - Állat örökbefogadás',
            'featured_animals' => $featured_animals,
            'species' => $species,
            'total_animals' => Animal::where('status', 'Available')->count(),
            'total_shelters' => \App\Models\Shelter::count()
        ];
        
        return view('home', $data);
    }
    
    /**
     * Rólunk oldal megjelenítése
     */
    public function about()
    {
        $data = [
            'title' => 'Rólunk',
            'mission' => 'Célunk, hogy minden állatnak megtalálja a tökéletes otthonát. Összekötjük a menhelyeket és a potenciális örökbefogadókat, hogy minden állatnak esélye legyen egy szerető családban élni.',
            'stats' => [
                'Örökbefogadott állatok' => Animal::where('status', 'Adopted')->count(),
                'Aktív menhelyek' => \App\Models\Shelter::count(),
                'Elérhető állatok' => Animal::where('status', 'Available')->count(),
                'Összes faj' => Species::count()
            ],
            'values' => [
                'Felelős örökbefogadás' => 'Minden állat egyedülálló, és megfelelő gondoskodást érdemel.',
                'Menhelyek támogatása' => 'Segítünk a menhelyeknek, hogy minél több állatot megmentsenek.',
                'Közösségépítés' => 'Összehozzuk az állatbarát embereket.',
                'Oktatás' => 'Tudást adunk az állatok megfelelő gondozásáról.'
            ]
        ];
        
        return view('about', $data);
    }
    
    /**
     * Kapcsolat oldal megjelenítése
     */
    public function contact()
    {
        $shelters = \App\Models\Shelter::all();
        
        $data = [
            'title' => 'Kapcsolat',
            'shelters' => $shelters,
            'contact_info' => [
                'email' => 'info@hazahozlak.hu',
                'phone' => '+36 1 234 5678',
                'address' => '1234 Budapest, Állatbarát utca 1.'
            ],
            'opening_hours' => [
                'Hétfő - Péntek' => '9:00 - 18:00',
                'Szombat' => '10:00 - 16:00',
                'Vasárnap' => 'Zárva'
            ]
        ];
        
        return view('contact', $data);
    }
    
    /**
     * Kapcsolati űrlap feldolgozása
     */
    public function sendContact(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'message' => 'required|string|max:1000'
        ]);
        
        // Itt feldolgoznánk az üzenetet (pl. email küldése, adatbázisba mentés)
        
        return redirect()->route('contact')->with('success', 'Üzenet sikeresen elküldve!');
    }
}
