<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Shelter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    /**
     * Bejelentkezési oldal megjelenítése
     */
    public function showLogin()
    {
        return view('auth.login');
    }

    /**
     * Bejelentkezés feldolgozása
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $email = $request->email;
        $password = $request->password;

        // Próbáljuk meg először a users táblából (örökbefogadók)
        if (Auth::guard('web')->attempt(['email' => $email, 'password' => $password], $request->boolean('remember'))) {
            $request->session()->regenerate();
            return redirect()->intended(route('home'))
                ->with('success', 'Sikeresen bejelentkeztél örökbefogadóként!');
        }

        // Ha nem sikerült, próbáljuk meg a shelters táblából (menhelyek)
        if (Auth::guard('shelters')->attempt(['email' => $email, 'password' => $password], $request->boolean('remember'))) {
            $request->session()->regenerate();
            return redirect()->intended(route('home'))
                ->with('success', 'Sikeresen bejelentkeztél menhelyként!');
        }

        return back()->withErrors([
            'email' => 'A megadott adatok nem egyeznek a rendszerben tárolt adatokkal.',
        ])->onlyInput('email');
    }

    /**
     * Regisztrációs oldal megjelenítése
     */
    public function showRegister()
    {
        return view('auth.register');
    }

    /**
     * Regisztráció feldolgozása
     */
    public function register(Request $request)
    {
        $userType = $request->input('user_type', 'adopter');
        
        if ($userType === 'adopter') {
            $request->validate([
                'firstname' => 'required|string|max:100',
                'lastname' => 'required|string|max:100',
                'email' => 'required|string|email|max:100|unique:users',
                'password' => ['required', 'confirmed', Password::defaults()],
            ]);

            $user = User::create([
                'firstname' => $request->firstname,
                'lastname' => $request->lastname,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => 'user'
            ]);

            Auth::guard('web')->login($user);
            $successMessage = 'Sikeresen regisztráltál örökbefogadóként!';
        } else {
            $request->validate([
                'shelter_name' => 'required|string|max:200',
                'location' => 'required|string|max:200',
                'description' => 'required|string|max:1000',
                'email' => 'required|string|email|max:100|unique:shelters,email',
                'contact_email' => 'required|string|email|max:100|unique:shelters,contact_email',
                'password' => ['required', 'confirmed', Password::defaults()],
            ]);

            $shelter = Shelter::create([
                'name' => $request->shelter_name,
                'location' => $request->location,
                'email' => $request->email,
                'contact_email' => $request->contact_email,
                'description' => $request->description,
                'password' => Hash::make($request->password),
            ]);

            Auth::guard('shelters')->login($shelter);
            $successMessage = 'Sikeresen regisztráltál menhelyként!';
        }

        return redirect()->route('home')
            ->with('success', $successMessage);
    }

    /**
     * Kijelentkezés
     */
    public function logout(Request $request)
    {
        // Kijelentkezés mindkét guard-ból
        Auth::guard('web')->logout();
        Auth::guard('shelters')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')
            ->with('success', 'Sikeresen kijelentkeztél!');
    }

    /**
     * Profil oldal megjelenítése
     */
    public function profile()
    {
        $user = \App\Helpers\AuthHelper::getCurrentUser();
        $userType = \App\Helpers\AuthHelper::getUserType();
        
        if ($userType === 'adopter') {
            // Kedvencek lekérése (majd implementáljuk)
            $favoriteAnimals = collect(); // Placeholder
            return view('auth.profile-adopter', compact('user', 'favoriteAnimals'));
        } elseif ($userType === 'shelter') {
            // Menhely állatainak lekérése
            $shelterAnimals = $user->animals()->with(['species', 'breed'])->get();
            return view('auth.profile-shelter', compact('user', 'shelterAnimals'));
        }
        
        return redirect()->route('home')->with('error', 'Nem található felhasználó!');
    }

    /**
     * Profil frissítése
     */
    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'firstname' => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'email' => 'required|string|email|max:100|unique:users,email,' . $user->id,
        ]);

        $user->update($request->only(['firstname', 'lastname', 'email']));

        return redirect()->back()->with('success', 'Profil sikeresen frissítve!');
    }
}