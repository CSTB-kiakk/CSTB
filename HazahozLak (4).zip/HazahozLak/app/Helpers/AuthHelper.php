<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Auth;

class AuthHelper
{
    /**
     * Visszaadja a bejelentkezett felhasználó típusát
     */
    public static function getUserType()
    {
        if (Auth::guard('web')->check()) {
            return 'adopter';
        }
        
        if (Auth::guard('shelters')->check()) {
            return 'shelter';
        }
        
        return null;
    }
    
    /**
     * Visszaadja a bejelentkezett felhasználót (bármelyik típusból)
     */
    public static function getCurrentUser()
    {
        if (Auth::guard('web')->check()) {
            return Auth::guard('web')->user();
        }
        
        if (Auth::guard('shelters')->check()) {
            return Auth::guard('shelters')->user();
        }
        
        return null;
    }
    
    /**
     * Ellenőrzi, hogy örökbefogadó van-e bejelentkezve
     */
    public static function isAdopter()
    {
        return self::getUserType() === 'adopter';
    }
    
    /**
     * Ellenőrzi, hogy menhely van-e bejelentkezve
     */
    public static function isShelter()
    {
        return self::getUserType() === 'shelter';
    }
    
    /**
     * Visszaadja a megjelenítendő nevet
     */
    public static function getDisplayName()
    {
        $user = self::getCurrentUser();
        
        if (!$user) {
            return null;
        }
        
        return $user->getDisplayName();
    }
}
