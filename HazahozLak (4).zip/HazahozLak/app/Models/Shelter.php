<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Shelter extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'location',
        'email',
        'contact_email',
        'description',
        'password'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public $timestamps = false;

    public function animals()
    {
        return $this->hasMany(Animal::class);
    }

    public function donations()
    {
        return $this->hasMany(Donation::class);
    }

    public function getDisplayName()
    {
        return $this->name;
    }

    public function isShelter()
    {
        return true;
    }

    public function isAdopter()
    {
        return false;
    }
}
