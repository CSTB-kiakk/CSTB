<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Animal extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $fillable = [
        'shelter_id',
        'species_id', 
        'breed_id',
        'age',
        'name',
        'gender',
        'picture',
        'description',
        'status'
    ];

    public function shelter()
    {
        return $this->belongsTo(Shelter::class);
    }

    public function species()
    {
        return $this->belongsTo(Species::class);
    }

    public function breed()
    {
        return $this->belongsTo(Breed::class);
    }

    public function adoptionRequests()
    {
        return $this->hasMany(AdoptionRequest::class);
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }
}
