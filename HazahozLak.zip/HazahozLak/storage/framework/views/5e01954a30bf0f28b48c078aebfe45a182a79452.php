

<?php $__env->startSection('title', 'Regisztráció - HazaHozLak'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-plus text-primary" style="font-size: 3rem;"></i>
                        <h2 class="fw-bold mt-3">Regisztráció</h2>
                        <p class="text-muted">Válaszd ki a regisztráció típusát</p>
                    </div>

                    <!-- Regisztráció típus választó -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card registration-type-card" data-type="adopter">
                                <div class="card-body text-center p-4">
                                    <i class="fas fa-heart text-primary mb-3" style="font-size: 2.5rem;"></i>
                                    <h5 class="fw-bold">Örökbefogadó</h5>
                                    <p class="text-muted small">Személyes fiók állatok örökbefogadásához</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card registration-type-card" data-type="shelter">
                                <div class="card-body text-center p-4">
                                    <i class="fas fa-home text-primary mb-3" style="font-size: 2.5rem;"></i>
                                    <h5 class="fw-bold">Menhely</h5>
                                    <p class="text-muted small">Menhely fiók állatok feltöltéséhez</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Örökbefogadó regisztrációs form -->
                    <form method="POST" action="<?php echo e(route('register')); ?>" id="adopter-form" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_type" value="adopter">
                        
                        <h4 class="fw-bold mb-4 text-center">
                            <i class="fas fa-heart text-primary me-2"></i>Örökbefogadó regisztráció
                        </h4>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="adopter_firstname" class="form-label">Keresztnév</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="adopter_firstname" name="firstname" value="<?php echo e(old('firstname')); ?>">
                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="adopter_lastname" class="form-label">Vezetéknév</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="adopter_lastname" name="lastname" value="<?php echo e(old('lastname')); ?>">
                                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="adopter_email" class="form-label">Email cím</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="adopter_email" name="email" value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="adopter_password" class="form-label">Jelszó</label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="adopter_password" name="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="adopter_password_confirmation" class="form-label">Jelszó megerősítése</label>
                            <input type="password" class="form-control" 
                                   id="adopter_password_confirmation" name="password_confirmation">
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="adopter_terms" required>
                            <label class="form-check-label" for="adopter_terms">
                                Elfogadom a <a href="#" class="text-primary">felhasználási feltételeket</a>
                            </label>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-user-plus me-2"></i>Örökbefogadó regisztráció
                            </button>
                        </div>
                    </form>

                    <!-- Menhely regisztrációs form -->
                    <form method="POST" action="<?php echo e(route('register')); ?>" id="shelter-form" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_type" value="shelter">
                        
                        <h4 class="fw-bold mb-4 text-center">
                            <i class="fas fa-home text-primary me-2"></i>Menhely regisztráció
                        </h4>
                        
                        <div class="mb-3">
                            <label for="shelter_name" class="form-label">Menhely neve</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['shelter_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="shelter_name" name="shelter_name" value="<?php echo e(old('shelter_name')); ?>">
                            <?php $__errorArgs = ['shelter_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_location" class="form-label">Helyszín</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="shelter_location" name="location" value="<?php echo e(old('location')); ?>" 
                                   placeholder="pl. 7400 Kaposvár, Valami utca 3">
                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_description" class="form-label">Menhely leírása</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      id="shelter_description" name="description" rows="4" 
                                      placeholder="Írj rövid leírást a menhelyről..."><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_email" class="form-label">Bejelentkezési email cím</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="shelter_email" name="email" value="<?php echo e(old('email')); ?>" 
                                   placeholder="Ez az email címed a bejelentkezéshez">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Ezzel az email címmel tudsz bejelentkezni a rendszerbe</small>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_contact_email" class="form-label">Kapcsolattartási email cím</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['contact_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="shelter_contact_email" name="contact_email" value="<?php echo e(old('contact_email')); ?>" 
                                   placeholder="Ide fognak érkezni az örökbefogadási kérelmek">
                            <?php $__errorArgs = ['contact_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Ide fognak érkezni az örökbefogadási kérelmek és egyéb kapcsolattartás</small>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_password" class="form-label">Jelszó</label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="shelter_password" name="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="shelter_password_confirmation" class="form-label">Jelszó megerősítése</label>
                            <input type="password" class="form-control" 
                                   id="shelter_password_confirmation" name="password_confirmation">
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="shelter_terms" required>
                            <label class="form-check-label" for="shelter_terms">
                                Elfogadom a <a href="#" class="text-primary">felhasználási feltételeket</a>
                            </label>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-home me-2"></i>Menhely regisztráció
                            </button>
                        </div>
                    </form>

                    <div class="text-center mt-4">
                        <p class="text-muted">Már van fiókod? 
                            <a href="<?php echo e(route('login')); ?>" class="text-primary fw-bold">Jelentkezz be!</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const typeCards = document.querySelectorAll('.registration-type-card');
    const adopterForm = document.getElementById('adopter-form');
    const shelterForm = document.getElementById('shelter-form');
    
    typeCards.forEach(card => {
        card.addEventListener('click', function() {
            // Remove active class from all cards
            typeCards.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked card
            this.classList.add('active');
            
            const type = this.dataset.type;
            
            // Show/hide forms
            if (type === 'adopter') {
                adopterForm.style.display = 'block';
                shelterForm.style.display = 'none';
            } else {
                adopterForm.style.display = 'none';
                shelterForm.style.display = 'block';
            }
        });
    });
    
    // Set default selection
    typeCards[0].click();
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
.registration-type-card {
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.registration-type-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    border-color: #3b82f6;
}

.registration-type-card.active {
    border-color: #3b82f6;
    background-color: #f8fafc;
}

.registration-type-card.active .text-primary {
    color: #3b82f6 !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanuló\Desktop\HazahozLak\resources\views/auth/register.blade.php ENDPATH**/ ?>