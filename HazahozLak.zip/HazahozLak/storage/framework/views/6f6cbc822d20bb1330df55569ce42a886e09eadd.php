

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-envelope me-3"></i>Kapcsolat
                </h1>
                <p class="lead">Ha bármilyen kérdésed van, keress minket bizalommal!</p>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- Contact Info -->
            <div class="col-lg-4 mb-5">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">
                            <i class="fas fa-info-circle text-primary me-2"></i>Elérhetőségek
                        </h3>
                        <div class="mb-3">
                            <i class="fas fa-envelope text-primary me-2"></i>
                            <strong>Email:</strong> <?php echo e($contact_info['email']); ?>

                        </div>
                        <div class="mb-3">
                            <i class="fas fa-phone text-primary me-2"></i>
                            <strong>Telefon:</strong> <?php echo e($contact_info['phone']); ?>

                        </div>
                        <div class="mb-4">
                            <i class="fas fa-map-marker-alt text-primary me-2"></i>
                            <strong>Cím:</strong> <?php echo e($contact_info['address']); ?>

                        </div>
                        
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-clock text-primary me-2"></i>Nyitvatartás
                        </h5>
                        <?php $__currentLoopData = $opening_hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span><strong><?php echo e($day); ?>:</strong></span>
                                <span><?php echo e($hours); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">
                            <i class="fas fa-paper-plane text-primary me-2"></i>Küldj üzenetet
                        </h3>
                        
                        <form method="POST" action="<?php echo e(route('contact.send')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Név *</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Üzenet *</label>
                                <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="message" name="message" rows="5" required 
                                          placeholder="Írd ide az üzeneted..."><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i>Üzenet küldése
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shelters Section -->
        <?php if($shelters->count() > 0): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="fw-bold mb-4 text-center">
                    <i class="fas fa-home text-primary me-2"></i>Partnereink menhelyek
                </h3>
                <div class="row">
                    <?php $__currentLoopData = $shelters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shelter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?php echo e($shelter->name); ?></h5>
                                <p class="card-text">
                                    <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                    <?php echo e($shelter->location); ?>

                                </p>
                                <p class="card-text">
                                    <i class="fas fa-envelope text-primary me-2"></i>
                                    <?php echo e($shelter->contact_email); ?>

                                </p>
                                <?php if($shelter->description): ?>
                                    <p class="card-text"><?php echo e(Str::limit($shelter->description, 100)); ?></p>
                                <?php endif; ?>
                                <div class="mt-auto">
                                    <a href="mailto:<?php echo e($shelter->contact_email); ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-envelope me-1"></i>Email küldése
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\HazahozLak\resources\views/contact.blade.php ENDPATH**/ ?>