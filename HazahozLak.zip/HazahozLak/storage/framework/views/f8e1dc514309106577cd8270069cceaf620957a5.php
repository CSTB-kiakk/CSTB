

<?php $__env->startSection('title', 'Állataink - HazaHozLak'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12 text-center">
            <h1 class="fw-bold">Állataink</h1>
            <p class="lead text-muted">Válassz a kedvenc állatfajt közül vagy nézd meg az összes állatot</p>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar - Kategóriák -->
        <div class="col-lg-3 col-md-4 mb-4">
            <div class="card sidebar-card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-filter me-2"></i>Kategóriák
                    </h5>
                </div>
                <div class="card-body p-0">
                    <!-- Összes kategória -->
                    <div class="sidebar-item <?php echo e(!request()->has('species') && !request()->has('search') ? 'active' : ''); ?>"
                         onclick="location.href='<?php echo e(route('animals.categories')); ?>'">
                        <div class="d-flex align-items-center p-3">
                            <div class="sidebar-icon me-3">
                                <i class="fas fa-list"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0 fw-bold">Összes</h6>
                                <small class="text-muted"><?php echo e($total_animals); ?> állat</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Faj kategóriák -->
                    <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sidebar-item <?php echo e(request()->get('species') == $specie->id ? 'active' : ''); ?>"
                         onclick="location.href='<?php echo e(route('animals.categories', ['species' => $specie->id])); ?>'">
                        <div class="d-flex align-items-center p-3">
                            <div class="sidebar-icon me-3">
                                <?php switch($specie->name):
                                    case ('Kutyák'): ?>
                                        <i class="fas fa-dog"></i>
                                        <?php break; ?>
                                    <?php case ('Macskák'): ?>
                                        <i class="fas fa-cat"></i>
                                        <?php break; ?>
                                    <?php case ('Madarak'): ?>
                                        <i class="fas fa-dove"></i>
                                        <?php break; ?>
                                    <?php case ('Hüllők és kétéltűek'): ?>
                                        <i class="fas fa-frog"></i>
                                        <?php break; ?>
                                    <?php case ('Kisemlősök'): ?>
                                        <i class="fas fa-paw"></i>
                                        <?php break; ?>
                                    <?php case ('Lovak'): ?>
                                        <i class="fas fa-horse"></i>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <i class="fas fa-paw"></i>
                                <?php endswitch; ?>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0 fw-bold"><?php echo e($specie->name); ?></h6>
                                <small class="text-muted"><?php echo e($specie->animals_count); ?> állat</small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Main Content - Állatok -->
        <div class="col-lg-9 col-md-8">
            <!-- Állatok fejléc -->
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="fw-bold mb-3">
                        <?php if(request()->has('search')): ?>
                            Keresési eredmények: "<?php echo e(request('search')); ?>"
                            <small class="text-muted">(<?php echo e($animals->total()); ?> találat)</small>
                        <?php elseif(request('species')): ?>
                            <?php echo e($species->where('id', request('species'))->first()->name ?? 'Állatok'); ?>

                        <?php else: ?>
                            Összes állat
                        <?php endif; ?>
                    </h3>
                    
                    <?php if(request()->has('search')): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-search me-2"></i>
                            Keresés: "<?php echo e(request('search')); ?>" - <?php echo e($animals->total()); ?> találat
                            <a href="<?php echo e(route('animals.categories')); ?>" class="btn btn-sm btn-outline-primary ms-2">
                                <i class="fas fa-times me-1"></i>Keresés törlése
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Állatok listája -->
            <div class="row">
                <?php if($animals->count() > 0): ?>
                    <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card animal-card h-100">
                                <div class="position-relative">
                                    <img src="<?php echo e(asset('images/animals/' . $animal->picture)); ?>" 
                                         class="card-img-top" alt="<?php echo e($animal->name); ?>"
                                         style="height: 250px; object-fit: cover;">
                                    <span class="status-badge status-available">
                                        Elérhető
                                    </span>
                                </div>
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?php echo e($animal->name); ?></h5>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-tag me-1"></i><?php echo e($animal->species->name); ?> - <?php echo e($animal->breed->name); ?>

                                        </small>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-birthday-cake me-1"></i><?php echo e($animal->age); ?>

                                        </small>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-venus-mars me-1"></i><?php echo e($animal->gender); ?>

                                        </small>
                                    </p>
                                    <p class="card-text"><?php echo e(Str::limit($animal->description, 120)); ?></p>
                                    <div class="mt-auto">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i><?php echo e($animal->shelter->location); ?>

                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-home me-1"></i><?php echo e($animal->shelter->name); ?>

                                            </small>
                                        </div>
                                        <div class="d-grid gap-2">
                                            <a href="<?php echo e(route('animals.show', $animal->id)); ?>" class="btn btn-primary">
                                                <i class="fas fa-eye me-2"></i>Részletek
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="text-center py-5">
                            <i class="fas fa-paw fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">Nincs elérhető állat ebben a kategóriában</h4>
                            <p class="text-muted">Kérjük, próbálj meg más kategóriát választani.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if($animals->hasPages()): ?>
                <div class="row mt-4">
                    <div class="col-12">
                        <?php echo e($animals->links()); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
.sidebar-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: sticky;
    top: 20px;
}

.sidebar-item {
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 1px solid #f1f5f9;
}

.sidebar-item:last-child {
    border-bottom: none;
}

.sidebar-item:hover {
    background-color: #f8fafc;
    transform: translateX(5px);
}

.sidebar-item.active {
    background-color: #3b82f6;
    color: white;
}

.sidebar-item.active .text-muted {
    color: rgba(255, 255, 255, 0.8) !important;
}

.sidebar-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f1f5f9;
    border-radius: 10px;
    font-size: 1.2rem;
    color: #3b82f6;
    transition: all 0.3s ease;
}

.sidebar-item.active .sidebar-icon {
    background-color: rgba(255, 255, 255, 0.2);
    color: white;
}

.sidebar-item:hover .sidebar-icon {
    background-color: #3b82f6;
    color: white;
    transform: scale(1.1);
}

.animal-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    border-radius: 15px;
    overflow: hidden;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-available {
    background-color: #10b981;
    color: white;
}

/* Responsive design */
@media (max-width: 768px) {
    .sidebar-card {
        position: relative;
        top: 0;
        margin-bottom: 2rem;
    }
    
    .sidebar-item:hover {
        transform: none;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\HazahozLak\resources\views/animals/categories.blade.php ENDPATH**/ ?>