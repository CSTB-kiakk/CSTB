<?php

namespace App\Http\Controllers;

use App\Models\Animal;
use App\Models\Species;
use App\Models\Breed;
use App\Models\Shelter;
use App\Models\Favorite;
use Illuminate\Http\Request;

class AnimalController extends Controller
{
    /**
     * Összes állat megjelenítése kategóriák szerint
     */
    public function index(Request $request)
    {
        $query = Animal::with(['species', 'breed', 'shelter'])
            ->where('status', 'Available');

        // Kategória szűrés
        if ($request->has('species') && $request->species) {
            $query->where('species_id', $request->species);
        }

        // Fajta szűrés
        if ($request->has('breed') && $request->breed) {
            $query->where('breed_id', $request->breed);
        }

        // Keresés név alapján
        if ($request->has('search') && $request->search) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $animals = $query->paginate(12);
        $species = Species::withCount('animals')->get();
        $breeds = Breed::with('species')->get();

        return view('animals.index', compact('animals', 'species', 'breeds'));
    }

    /**
     * Egy állat részletes megjelenítése
     */
    public function show($id)
    {
        $animal = Animal::with(['species', 'breed', 'shelter'])
            ->findOrFail($id);

        // Kapcsolódó állatok (ugyanaz a faj)
        $related_animals = Animal::with(['species', 'breed', 'shelter'])
            ->where('species_id', $animal->species_id)
            ->where('id', '!=', $animal->id)
            ->where('status', 'Available')
            ->take(4)
            ->get();

        return view('animals.show', compact('animal', 'related_animals'));
    }

    /**
     * Kategóriák oldal és állatok listázása
     */
    public function categories(Request $request)
    {
        // Összes faj lekérése
        $species = Species::withCount('animals')->get();
        
        // Állatok lekérése szűréssel
        $query = Animal::with(['species', 'breed', 'shelter'])
            ->where('status', 'Available');

        // Kategória szűrés
        if ($request->has('species') && $request->species) {
            $query->where('species_id', $request->species);
        }

        // Keresési szűrés
        if ($request->has('search') && $request->search) {
            $searchTerm = $request->search;
            $query->where(function($q) use ($searchTerm) {
                $q->where('name', 'LIKE', "%{$searchTerm}%")
                  ->orWhere('description', 'LIKE', "%{$searchTerm}%")
                  ->orWhereHas('species', function($speciesQuery) use ($searchTerm) {
                      $speciesQuery->where('name', 'LIKE', "%{$searchTerm}%");
                  })
                  ->orWhereHas('breed', function($breedQuery) use ($searchTerm) {
                      $breedQuery->where('name', 'LIKE', "%{$searchTerm}%");
                  })
                  ->orWhereHas('shelter', function($shelterQuery) use ($searchTerm) {
                      $shelterQuery->where('name', 'LIKE', "%{$searchTerm}%")
                                   ->orWhere('location', 'LIKE', "%{$searchTerm}%");
                  });
            });
        }

        $animals = $query->paginate(12);
        $total_animals = Animal::where('status', 'Available')->count();
        
        return view('animals.categories', compact('species', 'animals', 'total_animals'));
    }

    /**
     * Kedvencek hozzáadása/eltávolítása
     */
    public function addFavorite(Request $request, $id)
    {
        if (!auth()->check()) {
            return response()->json(['error' => 'Be kell jelentkezned a kedvencek használatához'], 401);
        }

        // 1. Lépés: Bejelentkezett felhasználó ID-ja
        $user = auth()->user();
        $userId = $user->id;
        
        // 2. Lépés: Állat ID-ja (a $id paraméter)
        $animalId = $id;
        
        // 3. Lépés: Ellenőrizzük, hogy létezik-e az állat
        $animal = Animal::findOrFail($animalId);
        
        // 4. Lépés: Ellenőrizzük, hogy már kedvenc-e
        $existingFavorite = Favorite::where('user_id', $userId)
            ->where('animal_id', $animalId)
            ->first();

        if ($existingFavorite) {
            return response()->json([
                'success' => false, 
                'message' => 'Ez az állat már a kedvenceid között van'
            ]);
        }

        // 5. Lépés: Új sor hozzáadása a favorites táblához
        Favorite::create([
            'user_id' => $userId,
            'animal_id' => $animalId
        ]);

        return response()->json([
            'success' => true, 
            'message' => 'Sikeresen hozzáadva a kedvencekhez!',
            'user_id' => $userId,
            'animal_id' => $animalId
        ]);
    }

    public function checkFavorite($id)
    {
        if (!auth()->check()) {
            return response()->json(['is_favorite' => false]);
        }

        $user = auth()->user();
        $isFavorite = Favorite::where('user_id', $user->id)
            ->where('animal_id', $id)
            ->exists();

        return response()->json(['is_favorite' => $isFavorite]);
    }

    /**
     * Örökbefogadási kérelem
     */
    public function adoptionRequest(Request $request, $id)
    {
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Be kell jelentkezned az örökbefogadási kérelemhez');
        }

        $request->validate([
            'message' => 'required|string|max:1000'
        ]);

        $animal = Animal::findOrFail($id);

        // Itt létrehoznánk az örökbefogadási kérelmet
        // \App\Models\AdoptionRequest::create([...]);

        return redirect()->back()->with('success', 'Örökbefogadási kérelem sikeresen elküldve!');
    }
}