@extends('layouts.app')

@section('title', 'Állataink - HazaHozLak')

@section('content')
<div class="container py-5">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="fw-bold">Állataink</h1>
            <p class="text-muted">Találd meg a tökéletes társat a szerető családodnak</p>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="{{ route('animals.index') }}">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label for="species" class="form-label">Faj</label>
                                <select name="species" id="species" class="form-select">
                                    <option value="">Minden faj</option>
                                    @foreach($species as $specie)
                                        <option value="{{ $specie->id }}" {{ request('species') == $specie->id ? 'selected' : '' }}>
                                            {{ $specie->name }} ({{ $specie->animals_count }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="breed" class="form-label">Fajta</label>
                                <select name="breed" id="breed" class="form-select">
                                    <option value="">Minden fajta</option>
                                    @foreach($breeds as $breed)
                                        <option value="{{ $breed->id }}" {{ request('breed') == $breed->id ? 'selected' : '' }}>
                                            {{ $breed->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="search" class="form-label">Keresés név alapján</label>
                                <input type="text" name="search" id="search" class="form-control" 
                                       value="{{ request('search') }}" placeholder="Állat neve...">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-2"></i>Szűrés
                                </button>
                                <a href="{{ route('animals.index') }}" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-2"></i>Törlés
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Results Count -->
    <div class="row mb-3">
        <div class="col-12">
            <p class="text-muted">
                {{ $animals->total() }} állat található
                @if(request('species') || request('breed') || request('search'))
                    a megadott szűrők alapján
                @endif
            </p>
        </div>
    </div>

    <!-- Animals Grid -->
    @if($animals->count() > 0)
        <div class="row">
            @foreach($animals as $animal)
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card animal-card h-100">
                    <div class="position-relative">
                        <img src="{{ $animal->picture ? asset('images/animals/' . $animal->picture) : 'https://via.placeholder.com/400x300?text=' . urlencode($animal->name) }}" 
                             class="card-img-top" alt="{{ $animal->name }}">
                        <span class="status-badge status-{{ strtolower($animal->status) }}">
                            {{ $animal->status === 'Available' ? 'Elérhető' : ($animal->status === 'Pending' ? 'Foglalt' : 'Örökbefogadva') }}
                        </span>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">{{ $animal->name }}</h5>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-tag me-1"></i>{{ $animal->species->name }} - {{ $animal->breed->name }}
                            </small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-birthday-cake me-1"></i>{{ $animal->age }}
                            </small>
                        </p>
                        <p class="card-text">{{ Str::limit($animal->description, 120) }}</p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>{{ $animal->shelter->location }}
                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-home me-1"></i>{{ $animal->shelter->name }}
                                </small>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="{{ route('animals.show', $animal->id) }}" class="btn btn-primary">
                                    <i class="fas fa-eye me-2"></i>Részletek
                                </a>
                                @if($animal->status === 'Available')
                                    @auth
                                        <button class="btn btn-outline-success" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#adoptionModal{{ $animal->id }}">
                                            <i class="fas fa-heart me-2"></i>Örökbefogadás
                                        </button>
                                    @else
                                        <a href="{{ route('login') }}" class="btn btn-outline-success">
                                            <i class="fas fa-heart me-2"></i>Örökbefogadás
                                        </a>
                                    @endauth
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Adoption Modal -->
            @auth
            <div class="modal fade" id="adoptionModal{{ $animal->id }}" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Örökbefogadási kérelem - {{ $animal->name }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST" action="{{ route('animals.adoption-request', $animal->id) }}">
                            @csrf
                            <div class="modal-body">
                                <p>Kérjük, írd le, miért szeretnéd örökbefogadni <strong>{{ $animal->name }}</strong>-t:</p>
                                <div class="mb-3">
                                    <textarea name="message" class="form-control" rows="4" 
                                              placeholder="Mesélj magadról, a lakásról, tapasztalataidról..." required></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Mégse</button>
                                <button type="submit" class="btn btn-success">Kérelem elküldése</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            @endauth
            @endforeach
        </div>

        <!-- Pagination -->
        <div class="row">
            <div class="col-12">
                {{ $animals->links() }}
            </div>
        </div>
    @else
        <div class="row">
            <div class="col-12 text-center py-5">
                <i class="fas fa-search" style="font-size: 4rem; color: #ccc;"></i>
                <h3 class="mt-3">Nincs találat</h3>
                <p class="text-muted">Sajnos nem találtunk állatot a megadott szűrők alapján.</p>
                <a href="{{ route('animals.index') }}" class="btn btn-primary">
                    <i class="fas fa-refresh me-2"></i>Összes állat megtekintése
                </a>
            </div>
        </div>
    @endif
</div>
@endsection

