@extends('layouts.app')

@section('title', 'Állataink - HazaHozLak')

@section('content')
<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12 text-center">
            <h1 class="fw-bold">Állataink</h1>
            <p class="lead text-muted">Válassz a kedvenc állatfajt közül vagy nézd meg az összes állatot</p>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar - Kategóriák -->
        <div class="col-lg-3 col-md-4 mb-4">
            <div class="card sidebar-card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-filter me-2"></i>Kategóriák
                    </h5>
                </div>
                <div class="card-body p-0">
                    <!-- Összes kategória -->
                    <div class="sidebar-item {{ !request()->has('species') && !request()->has('search') ? 'active' : '' }}"
                         onclick="location.href='{{ route('animals.categories') }}'">
                        <div class="d-flex align-items-center p-3">
                            <div class="sidebar-icon me-3">
                                <i class="fas fa-list"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0 fw-bold">Összes</h6>
                                <small class="text-muted">{{ $total_animals }} állat</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Faj kategóriák -->
                    @foreach($species as $specie)
                    <div class="sidebar-item {{ request()->get('species') == $specie->id ? 'active' : '' }}"
                         onclick="location.href='{{ route('animals.categories', ['species' => $specie->id]) }}'">
                        <div class="d-flex align-items-center p-3">
                            <div class="sidebar-icon me-3">
                                @switch($specie->name)
                                    @case('Kutyák')
                                        <i class="fas fa-dog"></i>
                                        @break
                                    @case('Macskák')
                                        <i class="fas fa-cat"></i>
                                        @break
                                    @case('Madarak')
                                        <i class="fas fa-dove"></i>
                                        @break
                                    @case('Hüllők és kétéltűek')
                                        <i class="fas fa-frog"></i>
                                        @break
                                    @case('Kisemlősök')
                                        <i class="fas fa-paw"></i>
                                        @break
                                    @case('Lovak')
                                        <i class="fas fa-horse"></i>
                                        @break
                                    @default
                                        <i class="fas fa-paw"></i>
                                @endswitch
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0 fw-bold">{{ $specie->name }}</h6>
                                <small class="text-muted">{{ $specie->animals_count }} állat</small>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Main Content - Állatok -->
        <div class="col-lg-9 col-md-8">
            <!-- Állatok fejléc -->
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="fw-bold mb-3">
                        @if(request()->has('search'))
                            Keresési eredmények: "{{ request('search') }}"
                            <small class="text-muted">({{ $animals->total() }} találat)</small>
                        @elseif(request('species'))
                            {{ $species->where('id', request('species'))->first()->name ?? 'Állatok' }}
                        @else
                            Összes állat
                        @endif
                    </h3>
                    
                    @if(request()->has('search'))
                        <div class="alert alert-info">
                            <i class="fas fa-search me-2"></i>
                            Keresés: "{{ request('search') }}" - {{ $animals->total() }} találat
                            <a href="{{ route('animals.categories') }}" class="btn btn-sm btn-outline-primary ms-2">
                                <i class="fas fa-times me-1"></i>Keresés törlése
                            </a>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Állatok listája -->
            <div class="row">
                @if($animals->count() > 0)
                    @foreach($animals as $animal)
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card animal-card h-100">
                                <div class="position-relative">
                                    <img src="{{ asset('images/animals/' . $animal->picture) }}" 
                                         class="card-img-top" alt="{{ $animal->name }}"
                                         style="height: 250px; object-fit: cover;">
                                    <span class="status-badge status-available">
                                        Elérhető
                                    </span>
                                </div>
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title">{{ $animal->name }}</h5>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-tag me-1"></i>{{ $animal->species->name }} - {{ $animal->breed->name }}
                                        </small>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-birthday-cake me-1"></i>{{ $animal->age }}
                                        </small>
                                    </p>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-venus-mars me-1"></i>{{ $animal->gender }}
                                        </small>
                                    </p>
                                    <p class="card-text">{{ Str::limit($animal->description, 120) }}</p>
                                    <div class="mt-auto">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i>{{ $animal->shelter->location }}
                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-home me-1"></i>{{ $animal->shelter->name }}
                                            </small>
                                        </div>
                                        <div class="d-grid gap-2">
                                            <a href="{{ route('animals.show', $animal->id) }}" class="btn btn-primary">
                                                <i class="fas fa-eye me-2"></i>Részletek
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @else
                    <div class="col-12">
                        <div class="text-center py-5">
                            <i class="fas fa-paw fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">Nincs elérhető állat ebben a kategóriában</h4>
                            <p class="text-muted">Kérjük, próbálj meg más kategóriát választani.</p>
                        </div>
                    </div>
                @endif
            </div>

            <!-- Pagination -->
            @if($animals->hasPages())
                <div class="row mt-4">
                    <div class="col-12">
                        {{ $animals->links() }}
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('styles')
<style>
.sidebar-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: sticky;
    top: 20px;
}

.sidebar-item {
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 1px solid #f1f5f9;
}

.sidebar-item:last-child {
    border-bottom: none;
}

.sidebar-item:hover {
    background-color: #f8fafc;
    transform: translateX(5px);
}

.sidebar-item.active {
    background-color: #3b82f6;
    color: white;
}

.sidebar-item.active .text-muted {
    color: rgba(255, 255, 255, 0.8) !important;
}

.sidebar-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f1f5f9;
    border-radius: 10px;
    font-size: 1.2rem;
    color: #3b82f6;
    transition: all 0.3s ease;
}

.sidebar-item.active .sidebar-icon {
    background-color: rgba(255, 255, 255, 0.2);
    color: white;
}

.sidebar-item:hover .sidebar-icon {
    background-color: #3b82f6;
    color: white;
    transform: scale(1.1);
}

.animal-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    border-radius: 15px;
    overflow: hidden;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-available {
    background-color: #10b981;
    color: white;
}

/* Responsive design */
@media (max-width: 768px) {
    .sidebar-card {
        position: relative;
        top: 0;
        margin-bottom: 2rem;
    }
    
    .sidebar-item:hover {
        transform: none;
    }
}
</style>
@endsection
