@extends('layouts.app')

@section('title', $animal->name . ' - HazaHozLak')

@section('content')
<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Főoldal</a></li>
            <li class="breadcrumb-item"><a href="{{ route('animals.categories') }}">Állataink</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ $animal->name }}</li>
        </ol>
    </nav>

    <div class="row">
        <!-- Állat képe -->
        <div class="col-lg-6 mb-4">
            <div class="position-relative">
                <img src="{{ asset('images/animals/' . $animal->picture) }}" 
                     class="img-fluid rounded shadow" 
                     alt="{{ $animal->name }}"
                     style="width: 100%; height: 500px; object-fit: cover;">
                <span class="status-badge status-available position-absolute top-0 end-0 m-3">
                    Elérhető
                </span>
            </div>
        </div>

        <!-- Állat adatai -->
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-body">
                    <h1 class="card-title display-6 fw-bold text-primary mb-3">{{ $animal->name }}</h1>
                    
                    <!-- Alapadatok -->
                    <div class="row mb-4">
                        <div class="col-sm-6 mb-3">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-tag text-primary me-2"></i>
                                <div>
                                    <small class="text-muted d-block">Faj</small>
                                    <strong>{{ $animal->species->name }}</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-paw text-primary me-2"></i>
                                <div>
                                    <small class="text-muted d-block">Fajta</small>
                                    <strong>{{ $animal->breed->name }}</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-birthday-cake text-primary me-2"></i>
                                <div>
                                    <small class="text-muted d-block">Életkor</small>
                                    <strong>{{ $animal->age }}</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-venus-mars text-primary me-2"></i>
                                <div>
                                    <small class="text-muted d-block">Nem</small>
                                    <strong>{{ $animal->gender }}</strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Leírás -->
                    <div class="mb-4">
                        <h5 class="fw-bold mb-3">Leírás</h5>
                        <p class="text-muted">{{ $animal->description }}</p>
                    </div>

                    <!-- Oltások -->
                    @if($animal->vaccinations)
                    <div class="mb-4">
                        <h5 class="fw-bold mb-3">Oltások</h5>
                        <p class="text-muted">{{ $animal->vaccinations }}</p>
                    </div>
                    @endif

                    <!-- Menhely információ -->
                    <div class="card bg-light mb-4">
                        <div class="card-body">
                            <h5 class="fw-bold mb-3">
                                <i class="fas fa-home text-primary me-2"></i>Menhely információ
                            </h5>
                            <div class="row">
                                <div class="col-12 mb-2">
                                    <strong>{{ $animal->shelter->name }}</strong>
                                </div>
                                <div class="col-12 mb-2">
                                    <i class="fas fa-map-marker-alt text-muted me-1"></i>
                                    <span class="text-muted">{{ $animal->shelter->location }}</span>
                                </div>
                                @if($animal->shelter->phone)
                                <div class="col-12 mb-2">
                                    <i class="fas fa-phone text-muted me-1"></i>
                                    <span class="text-muted">{{ $animal->shelter->phone }}</span>
                                </div>
                                @endif
                                @if($animal->shelter->email)
                                <div class="col-12">
                                    <i class="fas fa-envelope text-muted me-1"></i>
                                    <span class="text-muted">{{ $animal->shelter->email }}</span>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Műveletek -->
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary btn-lg" onclick="alert('Örökbefogadási folyamat hamarosan elérhető!')">
                            <i class="fas fa-heart me-2"></i>Örökbefogadás
                        </button>
                        @auth
                        <button class="btn btn-outline-primary" id="favoriteBtn" onclick="addFavorite({{ $animal->id }})">
                            <i class="far fa-star me-2"></i>Kedvencekhez adás
                        </button>
                        @else
                        <a href="{{ route('login') }}" class="btn btn-outline-primary">
                            <i class="far fa-star me-2"></i>Kedvencekhez adás
                        </a>
                        @endauth
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Kapcsolódó állatok -->
    @if($related_animals->count() > 0)
    <div class="row mt-5">
        <div class="col-12">
            <h3 class="fw-bold mb-4">Kapcsolódó állatok</h3>
        </div>
        @foreach($related_animals as $related_animal)
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card animal-card h-100">
                <div class="position-relative">
                    <img src="{{ asset('images/animals/' . $related_animal->picture) }}"
                         class="card-img-top" alt="{{ $related_animal->name }}"
                         style="height: 250px; object-fit: cover;">
                    <span class="status-badge status-available">
                        Elérhető
                    </span>
                </div>
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $related_animal->name }}</h5>
                    <p class="card-text">
                        <small class="text-muted">
                            <i class="fas fa-tag me-1"></i>{{ $related_animal->species->name }} - {{ $related_animal->breed->name }}
                        </small>
                    </p>
                    <p class="card-text">{{ Str::limit($related_animal->description, 100) }}</p>
                    <div class="mt-auto">
                        <a href="{{ route('animals.show', $related_animal->id) }}" class="btn btn-primary">
                            <i class="fas fa-eye me-2"></i>Részletek
                        </a>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @endif
</div>
@endsection

@section('styles')
<style>
.status-badge {
    padding: 0.5rem 1rem;
    border-radius: 25px;
    font-size: 0.9rem;
    font-weight: 600;
}

.status-available {
    background-color: #10b981;
    color: white;
}

.animal-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    border-radius: 15px;
    overflow: hidden;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.breadcrumb {
    background-color: #f8f9fa;
    border-radius: 10px;
    padding: 1rem;
}

.breadcrumb-item a {
    color: #3b82f6;
    text-decoration: none;
}

.breadcrumb-item a:hover {
    text-decoration: underline;
}
</style>
@endsection

@section('scripts')
<script>
// Oldal betöltéskor ellenőrizzük, hogy kedvenc-e
document.addEventListener('DOMContentLoaded', function() {
    checkIfFavorite({{ $animal->id }});
});

function checkIfFavorite(animalId) {
    fetch(`/animals/${animalId}/favorite/check`, {
        method: 'GET',
        headers: {
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.is_favorite) {
            // Ha kedvenc, frissítjük a gombot
            updateButtonToFavorite();
        }
    })
    .catch(error => {
        console.log('Kedvenc állapot ellenőrzése sikertelen:', error);
    });
}

function updateButtonToFavorite() {
    const button = document.getElementById('favoriteBtn');
    if (button) {
        button.innerHTML = '<i class="fas fa-star me-2"></i>Kedvenc';
        button.classList.remove('btn-outline-primary');
        button.classList.add('btn-warning');
        button.disabled = true;
    }
}

function addFavorite(animalId) {
    const button = document.getElementById('favoriteBtn');
    
    // Loading állapot
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Hozzáadás...';
    
    console.log('Kedvenc hozzáadása - Állat ID:', animalId);
    
    fetch(`/animals/${animalId}/favorite`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Accept': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => {
        console.log('Válasz státusz:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Válasz adatok:', data);
        if (data.success) {
            // Gomb frissítése kedvenc állapotra
            updateButtonToFavorite();
            showToast(data.message, 'success');
        } else {
            showToast(data.message || 'Hiba történt', 'error');
            button.disabled = false;
            button.innerHTML = '<i class="far fa-star me-2"></i>Kedvencekhez adás';
        }
    })
    .catch(error => {
        console.error('Hiba:', error);
        showToast('Hiba történt a kedvenc hozzáadásakor', 'error');
        button.disabled = false;
        button.innerHTML = '<i class="far fa-star me-2"></i>Kedvencekhez adás';
    });
}

function showToast(message, type) {
    // Egyszerű toast üzenet
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'success' ? 'success' : 'danger'} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}
</script>
@endsection
