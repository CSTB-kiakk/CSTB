@extends('layouts.app')

@section('title', 'Profil - HazaHozLak')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">
                        <i class="fas fa-user me-2"></i>Örökbefogadó profil
                    </h4>
                </div>
                <div class="card-body p-4">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <div class="profile-avatar mb-3">
                                <i class="fas fa-user-circle text-primary" style="font-size: 8rem;"></i>
                            </div>
                            <h5 class="fw-bold">{{ $user->getFullName() }}</h5>
                            <p class="text-muted">Örökbefogadó</p>
                        </div>
                        <div class="col-md-8">
                            <h5 class="fw-bold mb-3">Személyes adatok</h5>
                            <div class="row mb-3">
                                <div class="col-sm-4">
                                    <strong>Keresztnév:</strong>
                                </div>
                                <div class="col-sm-8">
                                    {{ $user->firstname }}
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-4">
                                    <strong>Vezetéknév:</strong>
                                </div>
                                <div class="col-sm-8">
                                    {{ $user->lastname }}
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-4">
                                    <strong>Email cím:</strong>
                                </div>
                                <div class="col-sm-8">
                                    {{ $user->email }}
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-4">
                                    <strong>Regisztráció dátuma:</strong>
                                </div>
                                <div class="col-sm-8">
                                    {{ $user->created_at ? $user->created_at->format('Y.m.d') : 'N/A' }}
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <hr class="my-4">
                    
                    <div class="row">
                        <div class="col-12">
                            <h5 class="fw-bold mb-3">
                                <i class="fas fa-heart text-danger me-2"></i>Kedvenc állataim
                            </h5>
                            
                            @if(isset($favoriteAnimals) && $favoriteAnimals->count() > 0)
                                <div class="row">
                                    @foreach($favoriteAnimals as $animal)
                                        <div class="col-md-6 col-lg-4 mb-3">
                                            <div class="card h-100">
                                                <img src="{{ asset('images/animals/' . $animal->picture) }}" 
                                                     class="card-img-top" 
                                                     alt="{{ $animal->name }}"
                                                     style="height: 200px; object-fit: cover;">
                                                <div class="card-body">
                                                    <h6 class="card-title fw-bold">{{ $animal->name }}</h6>
                                                    <p class="card-text">
                                                        <small class="text-muted">
                                                            <i class="fas fa-paw me-1"></i>{{ $animal->species->name }}
                                                            <br>
                                                            <i class="fas fa-venus-mars me-1"></i>{{ $animal->gender }}
                                                            <br>
                                                            <i class="fas fa-home me-1"></i>{{ $animal->shelter->name }}
                                                        </small>
                                                    </p>
                                                </div>
                                                <div class="card-footer">
                                                    <a href="{{ route('animals.show', $animal->id) }}" 
                                                       class="btn btn-primary btn-sm w-100">
                                                        <i class="fas fa-eye me-1"></i>Részletek
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="text-center py-4">
                                    <i class="fas fa-heart text-muted" style="font-size: 3rem;"></i>
                                    <p class="text-muted mt-2">Még nincsenek kedvenc állataid.</p>
                                    <a href="{{ route('animals.categories') }}" class="btn btn-primary">
                                        <i class="fas fa-search me-1"></i>Állatok böngészése
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
