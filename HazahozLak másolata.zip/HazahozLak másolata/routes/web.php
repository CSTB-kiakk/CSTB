<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\AnimalController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Főoldal és statikus oldalak
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');
Route::post('/contact', [HomeController::class, 'sendContact'])->name('contact.send');

// UTF-8 teszt oldal
Route::get('/test-utf8', function () {
    return view('test-utf8');
})->name('test-utf8');

// Állatok
Route::get('/animals', [AnimalController::class, 'index'])->name('animals.index');
Route::get('/animals/categories', [AnimalController::class, 'categories'])->name('animals.categories');
Route::get('/animals/{id}', [AnimalController::class, 'show'])->name('animals.show');
Route::post('/animals/{id}/favorite', [AnimalController::class, 'toggleFavorite'])->name('animals.favorite');
Route::post('/animals/{id}/adoption-request', [AnimalController::class, 'adoptionRequest'])->name('animals.adoption-request');

// Autentikáció
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Védett útvonalak
Route::middleware('auth')->group(function () {
    Route::get('/profile', [AuthController::class, 'profile'])->name('profile');
    Route::post('/profile', [AuthController::class, 'updateProfile'])->name('profile.update');
});
