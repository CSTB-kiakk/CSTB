

<?php $__env->startSection('title', 'Állataink - HazaHozLak'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="fw-bold">Állataink</h1>
            <p class="text-muted">Találd meg a tökéletes társat a szerető családodnak</p>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('animals.index')); ?>">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label for="species" class="form-label">Faj</label>
                                <select name="species" id="species" class="form-select">
                                    <option value="">Minden faj</option>
                                    <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($specie->id); ?>" <?php echo e(request('species') == $specie->id ? 'selected' : ''); ?>>
                                            <?php echo e($specie->name); ?> (<?php echo e($specie->animals_count); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="breed" class="form-label">Fajta</label>
                                <select name="breed" id="breed" class="form-select">
                                    <option value="">Minden fajta</option>
                                    <?php $__currentLoopData = $breeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($breed->id); ?>" <?php echo e(request('breed') == $breed->id ? 'selected' : ''); ?>>
                                            <?php echo e($breed->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="search" class="form-label">Keresés név alapján</label>
                                <input type="text" name="search" id="search" class="form-control" 
                                       value="<?php echo e(request('search')); ?>" placeholder="Állat neve...">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-2"></i>Szűrés
                                </button>
                                <a href="<?php echo e(route('animals.index')); ?>" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-2"></i>Törlés
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Results Count -->
    <div class="row mb-3">
        <div class="col-12">
            <p class="text-muted">
                <?php echo e($animals->total()); ?> állat található
                <?php if(request('species') || request('breed') || request('search')): ?>
                    a megadott szűrők alapján
                <?php endif; ?>
            </p>
        </div>
    </div>

    <!-- Animals Grid -->
    <?php if($animals->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card animal-card h-100">
                    <div class="position-relative">
                        <img src="<?php echo e($animal->picture ? asset('images/animals/' . $animal->picture) : 'https://via.placeholder.com/400x300?text=' . urlencode($animal->name)); ?>" 
                             class="card-img-top" alt="<?php echo e($animal->name); ?>">
                        <span class="status-badge status-<?php echo e(strtolower($animal->status)); ?>">
                            <?php echo e($animal->status === 'Available' ? 'Elérhető' : ($animal->status === 'Pending' ? 'Foglalt' : 'Örökbefogadva')); ?>

                        </span>
                        <?php if(auth()->guard()->check()): ?>
                        <button class="btn btn-sm btn-light position-absolute" 
                                style="top: 10px; left: 10px; z-index: 10;"
                                onclick="toggleFavorite(<?php echo e($animal->id); ?>)">
                            <i class="fas fa-heart text-danger"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($animal->name); ?></h5>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-tag me-1"></i><?php echo e($animal->species->name); ?> - <?php echo e($animal->breed->name); ?>

                            </small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-birthday-cake me-1"></i><?php echo e($animal->age); ?>

                            </small>
                        </p>
                        <p class="card-text"><?php echo e(Str::limit($animal->description, 120)); ?></p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i><?php echo e($animal->shelter->location); ?>

                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-home me-1"></i><?php echo e($animal->shelter->name); ?>

                                </small>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="<?php echo e(route('animals.show', $animal->id)); ?>" class="btn btn-primary">
                                    <i class="fas fa-eye me-2"></i>Részletek
                                </a>
                                <?php if($animal->status === 'Available'): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <button class="btn btn-outline-success" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#adoptionModal<?php echo e($animal->id); ?>">
                                            <i class="fas fa-heart me-2"></i>Örökbefogadás
                                        </button>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-success">
                                            <i class="fas fa-heart me-2"></i>Örökbefogadás
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Adoption Modal -->
            <?php if(auth()->guard()->check()): ?>
            <div class="modal fade" id="adoptionModal<?php echo e($animal->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Örökbefogadási kérelem - <?php echo e($animal->name); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST" action="<?php echo e(route('animals.adoption-request', $animal->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <p>Kérjük, írd le, miért szeretnéd örökbefogadni <strong><?php echo e($animal->name); ?></strong>-t:</p>
                                <div class="mb-3">
                                    <textarea name="message" class="form-control" rows="4" 
                                              placeholder="Mesélj magadról, a lakásról, tapasztalataidról..." required></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Mégse</button>
                                <button type="submit" class="btn btn-success">Kérelem elküldése</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="row">
            <div class="col-12">
                <?php echo e($animals->links()); ?>

            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-12 text-center py-5">
                <i class="fas fa-search" style="font-size: 4rem; color: #ccc;"></i>
                <h3 class="mt-3">Nincs találat</h3>
                <p class="text-muted">Sajnos nem találtunk állatot a megadott szűrők alapján.</p>
                <a href="<?php echo e(route('animals.index')); ?>" class="btn btn-primary">
                    <i class="fas fa-refresh me-2"></i>Összes állat megtekintése
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function toggleFavorite(animalId) {
    fetch(`/animals/${animalId}/favorite`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Itt frissíthetnénk a UI-t
            console.log('Kedvenc hozzáadva');
        }
    })
    .catch(error => {
        console.error('Hiba:', error);
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanuló\Desktop\HazahozLak\resources\views/animals/index.blade.php ENDPATH**/ ?>