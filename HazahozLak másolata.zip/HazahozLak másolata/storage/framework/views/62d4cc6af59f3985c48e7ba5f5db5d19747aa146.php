

<?php $__env->startSection('title', 'Állataink - HazaHozLak'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <!-- Page Header -->
    <div class="row mb-5">
        <div class="col-12 text-center">
            <h1 class="fw-bold">Állataink</h1>
            <p class="lead text-muted">Válassz a kedvenc állatfajt közül vagy nézd meg az összes állatot</p>
        </div>
    </div>

    <!-- Kategóriák -->
    <div class="row mb-5">
        <div class="col-12">
            <h3 class="fw-bold mb-4">Kategóriák</h3>
        </div>
        <div class="col-md-4 col-lg-2 mb-4">
            <div class="card category-card h-100 <?php echo e(!request('species') ? 'bg-primary text-white' : 'bg-white'); ?>" 
                 onclick="location.href='<?php echo e(route('animals.categories')); ?>'">
                <div class="card-body text-center p-4">
                    <div class="category-icon mb-3">
                        <i class="fas fa-list" style="font-size: 3rem;"></i>
                    </div>
                    <h6 class="fw-bold">Összes</h6>
                    <small><?php echo e($total_animals); ?> állat</small>
                </div>
            </div>
        </div>
        <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-2 mb-4">
            <div class="card category-card h-100 <?php echo e(request('species') == $specie->id ? 'bg-primary text-white' : 'bg-white'); ?>" 
                 onclick="location.href='<?php echo e(route('animals.categories', ['species' => $specie->id])); ?>'">
                <div class="card-body text-center p-4">
                    <div class="category-icon mb-3">
                        <?php switch($specie->name):
                            case ('Kutyák'): ?>
                                <i class="fas fa-dog" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php case ('Macskák'): ?>
                                <i class="fas fa-cat" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php case ('Madarak'): ?>
                                <i class="fas fa-dove" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php case ('Hüllők és kétéltűek'): ?>
                                <i class="fas fa-frog" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php case ('Kisemlősök'): ?>
                                <i class="fas fa-paw" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php case ('Lovak'): ?>
                                <i class="fas fa-horse" style="font-size: 3rem;"></i>
                                <?php break; ?>
                            <?php default: ?>
                                <i class="fas fa-paw" style="font-size: 3rem;"></i>
                        <?php endswitch; ?>
                    </div>
                    <h6 class="fw-bold"><?php echo e($specie->name); ?></h6>
                    <small><?php echo e($specie->animals_count); ?> állat</small>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Állatok listája -->
    <div class="row">
        <div class="col-12">
            <h3 class="fw-bold mb-4">
                <?php if(request('species')): ?>
                    <?php echo e($species->where('id', request('species'))->first()->name ?? 'Állatok'); ?>

                <?php else: ?>
                    Összes állat
                <?php endif; ?>
            </h3>
        </div>
        
        <?php if($animals->count() > 0): ?>
            <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card animal-card h-100">
                        <div class="position-relative">
                            <img src="<?php echo e(asset('images/animals/' . $animal->picture)); ?>" 
                                 class="card-img-top" alt="<?php echo e($animal->name); ?>"
                                 style="height: 250px; object-fit: cover;">
                            <span class="status-badge status-available">
                                Elérhető
                            </span>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo e($animal->name); ?></h5>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-tag me-1"></i><?php echo e($animal->species->name); ?> - <?php echo e($animal->breed->name); ?>

                                </small>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-birthday-cake me-1"></i><?php echo e($animal->age); ?>

                                </small>
                            </p>
                            <p class="card-text"><?php echo e(Str::limit($animal->description, 120)); ?></p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i><?php echo e($animal->shelter->location); ?>

                                    </small>
                                    <small class="text-muted">
                                        <i class="fas fa-home me-1"></i><?php echo e($animal->shelter->name); ?>

                                    </small>
                                </div>
                                <div class="d-grid gap-2">
                                    <a href="<?php echo e(route('animals.show', $animal->id)); ?>" class="btn btn-primary">
                                        <i class="fas fa-eye me-2"></i>Részletek
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="fas fa-paw fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nincs elérhető állat ebben a kategóriában</h4>
                    <p class="text-muted">Kérjük, próbálj meg más kategóriát választani.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if($animals->hasPages()): ?>
        <div class="row mt-5">
            <div class="col-12">
                <?php echo e($animals->links()); ?>

            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
.category-card {
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    border-color: #3b82f6;
}

.category-card:hover .fas {
    transform: scale(1.1);
    transition: transform 0.3s ease;
}

.animal-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    border-radius: 15px;
    overflow: hidden;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-available {
    background-color: #10b981;
    color: white;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanuló\Desktop\HazahozLak\resources\views/animals/categories.blade.php ENDPATH**/ ?>