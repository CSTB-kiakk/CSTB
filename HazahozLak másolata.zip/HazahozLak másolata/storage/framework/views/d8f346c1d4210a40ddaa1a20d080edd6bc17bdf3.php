

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-paw me-3"></i>HazaHozLak
                </h1>
                <p class="lead mb-4">
                    Minden állatnak megérdemli a szerető otthont. Segíts nekünk összekötni a menhelyeket és a potenciális örökbefogadókat!
                </p>
                <div class="d-flex gap-3">
                    <a href="<?php echo e(route('animals.categories')); ?>" class="btn btn-light btn-lg">
                        <i class="fas fa-search me-2"></i>Állataink böngészése
                    </a>
                    <a href="<?php echo e(route('about')); ?>" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-info-circle me-2"></i>Tudj meg többet
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="text-center">
                    <i class="fas fa-heart" style="font-size: 8rem; opacity: 0.3;"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($total_animals); ?></div>
                    <div class="text-muted">Elérhető állat</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($total_shelters); ?></div>
                    <div class="text-muted">Aktív menhely</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($species->count()); ?></div>
                    <div class="text-muted">Különböző faj</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number">100+</div>
                    <div class="text-muted">Sikeres örökbefogadás</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Animals Slider -->
<?php if($featured_animals->count() > 0): ?>
<section class="py-5">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h2 class="fw-bold">Kiemelt állataink</h2>
                <p class="text-muted">Nézd meg a legújabb örökbefogadható állatokat</p>
            </div>
        </div>
        
        <div id="animalsCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $featured_animals->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                    <div class="row">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card animal-card h-100">
                                <div class="position-relative">
                                    <img src="<?php echo e($animal->picture ? asset('images/animals/' . $animal->picture) : 'https://via.placeholder.com/300x250?text=' . urlencode($animal->name)); ?>" 
                                         class="card-img-top" alt="<?php echo e($animal->name); ?>">
                                    <span class="status-badge status-<?php echo e(strtolower($animal->status)); ?>">
                                        <?php echo e($animal->status === 'Available' ? 'Elérhető' : ($animal->status === 'Pending' ? 'Foglalt' : 'Örökbefogadva')); ?>

                                    </span>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($animal->name); ?></h5>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-tag me-1"></i><?php echo e($animal->species->name); ?> - <?php echo e($animal->breed->name); ?>

                                        </small>
                                    </p>
                                    <p class="card-text"><?php echo e(Str::limit($animal->description, 100)); ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <i class="fas fa-map-marker-alt me-1"></i><?php echo e($animal->shelter->location); ?>

                                        </small>
                                        <a href="<?php echo e(route('animals.show', $animal->id)); ?>" class="btn btn-primary btn-sm">
                                            Részletek
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <?php if($featured_animals->count() > 3): ?>
            <button class="carousel-control-prev" type="button" data-bs-target="#animalsCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#animalsCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?php echo e(route('animals.categories')); ?>" class="btn btn-outline-primary">
                <i class="fas fa-list me-2"></i>Összes állat megtekintése
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Categories Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h2 class="fw-bold">Kategóriák</h2>
                <p class="text-muted">Válassz a kedvenc állatfajt közül</p>
            </div>
        </div>
        
        <div class="row">
            <?php $__currentLoopData = $species; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-lg-2 mb-4">
                <div class="category-card bg-white" onclick="location.href='<?php echo e(route('animals.categories', ['species' => $specie->id])); ?>'">
                    <div class="category-icon">
                        <?php switch($specie->name):
                            case ('Kutyák'): ?>
                                <i class="fas fa-dog text-primary"></i>
                                <?php break; ?>
                            <?php case ('Macskák'): ?>
                                <i class="fas fa-cat text-info"></i>
                                <?php break; ?>
                            <?php case ('Madarak'): ?>
                                <i class="fas fa-dove text-warning"></i>
                                <?php break; ?>
                            <?php case ('Hüllők és kétéltűek'): ?>
                                <i class="fas fa-frog text-success"></i>
                                <?php break; ?>
                            <?php case ('Kisemlősök'): ?>
                                <i class="fas fa-paw text-secondary"></i>
                                <?php break; ?>
                            <?php case ('Lovak'): ?>
                                <i class="fas fa-horse text-dark"></i>
                                <?php break; ?>
                            <?php default: ?>
                                <i class="fas fa-paw text-muted"></i>
                        <?php endswitch; ?>
                    </div>
                    <h6 class="fw-bold"><?php echo e($specie->name); ?></h6>
                    <small class="text-muted"><?php echo e($specie->animals_count); ?> állat</small>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?php echo e(route('animals.categories')); ?>" class="btn btn-primary">
                <i class="fas fa-th-large me-2"></i>Összes kategória
            </a>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2 class="fw-bold mb-4">Készen állsz egy új családtag befogadására?</h2>
                <p class="lead mb-4">Több mint <?php echo e($total_animals); ?> állat várja a szerető otthonát. Találd meg a tökéletes társat!</p>
                <a href="<?php echo e(route('animals.categories')); ?>" class="btn btn-primary btn-lg me-3">
                    <i class="fas fa-search me-2"></i>Állataink böngészése
                </a>
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-user-plus me-2"></i>Regisztrálj most
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanuló\Desktop\HazahozLak\resources\views/home.blade.php ENDPATH**/ ?>