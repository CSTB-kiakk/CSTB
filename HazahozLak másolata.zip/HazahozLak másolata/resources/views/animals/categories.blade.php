@extends('layouts.app')

@section('title', 'Állataink - HazaHozLak')

@section('content')
<div class="container py-5">
    <!-- Page Header -->
    <div class="row mb-5">
        <div class="col-12 text-center">
            <h1 class="fw-bold">Állataink</h1>
            <p class="lead text-muted">Válassz a kedvenc állatfajt közül vagy nézd meg az összes állatot</p>
        </div>
    </div>

    <!-- Kategóriák -->
    <div class="row mb-5">
        <div class="col-12">
            <h3 class="fw-bold mb-4">Kategóriák</h3>
        </div>
        <div class="col-md-4 col-lg-2 mb-4">
            <div class="card category-card h-100 {{ !request('species') ? 'bg-primary text-white' : 'bg-white' }}" 
                 onclick="location.href='{{ route('animals.categories') }}'">
                <div class="card-body text-center p-4">
                    <div class="category-icon mb-3">
                        <i class="fas fa-list" style="font-size: 3rem;"></i>
                    </div>
                    <h6 class="fw-bold">Összes</h6>
                    <small>{{ $total_animals }} állat</small>
                </div>
            </div>
        </div>
        @foreach($species as $specie)
        <div class="col-md-4 col-lg-2 mb-4">
            <div class="card category-card h-100 {{ request('species') == $specie->id ? 'bg-primary text-white' : 'bg-white' }}" 
                 onclick="location.href='{{ route('animals.categories', ['species' => $specie->id]) }}'">
                <div class="card-body text-center p-4">
                    <div class="category-icon mb-3">
                        @switch($specie->name)
                            @case('Kutyák')
                                <i class="fas fa-dog" style="font-size: 3rem;"></i>
                                @break
                            @case('Macskák')
                                <i class="fas fa-cat" style="font-size: 3rem;"></i>
                                @break
                            @case('Madarak')
                                <i class="fas fa-dove" style="font-size: 3rem;"></i>
                                @break
                            @case('Hüllők és kétéltűek')
                                <i class="fas fa-frog" style="font-size: 3rem;"></i>
                                @break
                            @case('Kisemlősök')
                                <i class="fas fa-paw" style="font-size: 3rem;"></i>
                                @break
                            @case('Lovak')
                                <i class="fas fa-horse" style="font-size: 3rem;"></i>
                                @break
                            @default
                                <i class="fas fa-paw" style="font-size: 3rem;"></i>
                        @endswitch
                    </div>
                    <h6 class="fw-bold">{{ $specie->name }}</h6>
                    <small>{{ $specie->animals_count }} állat</small>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <!-- Állatok listája -->
    <div class="row">
        <div class="col-12">
            <h3 class="fw-bold mb-4">
                @if(request('species'))
                    {{ $species->where('id', request('species'))->first()->name ?? 'Állatok' }}
                @else
                    Összes állat
                @endif
            </h3>
        </div>
        
        @if($animals->count() > 0)
            @foreach($animals as $animal)
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card animal-card h-100">
                        <div class="position-relative">
                            <img src="{{ asset('images/animals/' . $animal->picture) }}" 
                                 class="card-img-top" alt="{{ $animal->name }}"
                                 style="height: 250px; object-fit: cover;">
                            <span class="status-badge status-available">
                                Elérhető
                            </span>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">{{ $animal->name }}</h5>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-tag me-1"></i>{{ $animal->species->name }} - {{ $animal->breed->name }}
                                </small>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-birthday-cake me-1"></i>{{ $animal->age }}
                                </small>
                            </p>
                            <p class="card-text">{{ Str::limit($animal->description, 120) }}</p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i>{{ $animal->shelter->location }}
                                    </small>
                                    <small class="text-muted">
                                        <i class="fas fa-home me-1"></i>{{ $animal->shelter->name }}
                                    </small>
                                </div>
                                <div class="d-grid gap-2">
                                    <a href="{{ route('animals.show', $animal->id) }}" class="btn btn-primary">
                                        <i class="fas fa-eye me-2"></i>Részletek
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @else
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="fas fa-paw fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nincs elérhető állat ebben a kategóriában</h4>
                    <p class="text-muted">Kérjük, próbálj meg más kategóriát választani.</p>
                </div>
            </div>
        @endif
    </div>

    <!-- Pagination -->
    @if($animals->hasPages())
        <div class="row mt-5">
            <div class="col-12">
                {{ $animals->links() }}
            </div>
        </div>
    @endif
</div>
@endsection

@section('styles')
<style>
.category-card {
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid transparent;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    border-color: #3b82f6;
}

.category-card:hover .fas {
    transform: scale(1.1);
    transition: transform 0.3s ease;
}

.animal-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: none;
    border-radius: 15px;
    overflow: hidden;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-available {
    background-color: #10b981;
    color: white;
}
</style>
@endsection