@extends('layouts.app')

@section('title', $title)

@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-paw me-3"></i>HazaHozLak
                </h1>
                <p class="lead mb-4">
                    Minden állatnak megérdemli a szerető otthont. Segíts nekünk összekötni a menhelyeket és a potenciális örökbefogadókat!
                </p>
                <div class="d-flex gap-3">
                    <a href="{{ route('animals.categories') }}" class="btn btn-light btn-lg">
                        <i class="fas fa-search me-2"></i>Állataink böngészése
                    </a>
                    <a href="{{ route('about') }}" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-info-circle me-2"></i>Tudj meg többet
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="text-center">
                    <i class="fas fa-heart" style="font-size: 8rem; opacity: 0.3;"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number">{{ $total_animals }}</div>
                    <div class="text-muted">Elérhető állat</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number">{{ $total_shelters }}</div>
                    <div class="text-muted">Aktív menhely</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number">{{ $species->count() }}</div>
                    <div class="text-muted">Különböző faj</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-item">
                    <div class="stat-number">100+</div>
                    <div class="text-muted">Sikeres örökbefogadás</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Animals Slider -->
@if($featured_animals->count() > 0)
<section class="py-5">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h2 class="fw-bold">Kiemelt állataink</h2>
                <p class="text-muted">Nézd meg a legújabb örökbefogadható állatokat</p>
            </div>
        </div>
        
        <div id="animalsCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                @foreach($featured_animals->chunk(3) as $chunk)
                <div class="carousel-item {{ $loop->first ? 'active' : '' }}">
                    <div class="row">
                        @foreach($chunk as $animal)
                        <div class="col-md-4 mb-4">
                            <div class="card animal-card h-100">
                                <div class="position-relative">
                                    <img src="{{ $animal->picture ? asset('images/animals/' . $animal->picture) : 'https://via.placeholder.com/300x250?text=' . urlencode($animal->name) }}" 
                                         class="card-img-top" alt="{{ $animal->name }}">
                                    <span class="status-badge status-{{ strtolower($animal->status) }}">
                                        {{ $animal->status === 'Available' ? 'Elérhető' : ($animal->status === 'Pending' ? 'Foglalt' : 'Örökbefogadva') }}
                                    </span>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">{{ $animal->name }}</h5>
                                    <p class="card-text">
                                        <small class="text-muted">
                                            <i class="fas fa-tag me-1"></i>{{ $animal->species->name }} - {{ $animal->breed->name }}
                                        </small>
                                    </p>
                                    <p class="card-text">{{ Str::limit($animal->description, 100) }}</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <i class="fas fa-map-marker-alt me-1"></i>{{ $animal->shelter->location }}
                                        </small>
                                        <a href="{{ route('animals.show', $animal->id) }}" class="btn btn-primary btn-sm">
                                            Részletek
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endforeach
            </div>
            
            @if($featured_animals->count() > 3)
            <button class="carousel-control-prev" type="button" data-bs-target="#animalsCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#animalsCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
            @endif
        </div>
        
        <div class="text-center mt-4">
            <a href="{{ route('animals.categories') }}" class="btn btn-outline-primary">
                <i class="fas fa-list me-2"></i>Összes állat megtekintése
            </a>
        </div>
    </div>
</section>
@endif

<!-- Categories Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h2 class="fw-bold">Kategóriák</h2>
                <p class="text-muted">Válassz a kedvenc állatfajt közül</p>
            </div>
        </div>
        
        <div class="row">
            @foreach($species as $specie)
            <div class="col-md-4 col-lg-2 mb-4">
                <div class="category-card bg-white" onclick="location.href='{{ route('animals.categories', ['species' => $specie->id]) }}'">
                    <div class="category-icon">
                        @switch($specie->name)
                            @case('Kutyák')
                                <i class="fas fa-dog text-primary"></i>
                                @break
                            @case('Macskák')
                                <i class="fas fa-cat text-info"></i>
                                @break
                            @case('Madarak')
                                <i class="fas fa-dove text-warning"></i>
                                @break
                            @case('Hüllők és kétéltűek')
                                <i class="fas fa-frog text-success"></i>
                                @break
                            @case('Kisemlősök')
                                <i class="fas fa-paw text-secondary"></i>
                                @break
                            @case('Lovak')
                                <i class="fas fa-horse text-dark"></i>
                                @break
                            @default
                                <i class="fas fa-paw text-muted"></i>
                        @endswitch
                    </div>
                    <h6 class="fw-bold">{{ $specie->name }}</h6>
                    <small class="text-muted">{{ $specie->animals_count }} állat</small>
                </div>
            </div>
            @endforeach
        </div>
        
        <div class="text-center mt-4">
            <a href="{{ route('animals.categories') }}" class="btn btn-primary">
                <i class="fas fa-th-large me-2"></i>Összes kategória
            </a>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2 class="fw-bold mb-4">Készen állsz egy új családtag befogadására?</h2>
                <p class="lead mb-4">Több mint {{ $total_animals }} állat várja a szerető otthonát. Találd meg a tökéletes társat!</p>
                <a href="{{ route('animals.categories') }}" class="btn btn-primary btn-lg me-3">
                    <i class="fas fa-search me-2"></i>Állataink böngészése
                </a>
                @guest
                <a href="{{ route('register') }}" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-user-plus me-2"></i>Regisztrálj most
                </a>
                @endguest
            </div>
        </div>
    </div>
</section>
@endsection
