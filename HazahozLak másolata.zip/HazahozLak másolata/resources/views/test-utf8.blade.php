@extends('layouts.app')

@section('title', 'UTF-8 Teszt')

@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-12">
            <h1 class="fw-bold mb-4">UTF-8 Kódolás Teszt</h1>
            
            <div class="card">
                <div class="card-body">
                    <h3>Magyar karakterek tesztelése:</h3>
                    <ul class="list-unstyled">
                        <li>✅ Á, É, Í, Ó, Ö, Ő, Ú, Ü, Ű (nagybetűk)</li>
                        <li>✅ á, é, í, ó, ö, ő, ú, ü, ű (kisbetűk)</li>
                        <li>✅ Ő, Ű (dupla ékezetes betűk)</li>
                    </ul>
                    
                    <h3 class="mt-4">Adatbázisból származó adatok:</h3>
                    @php
                        $animals = \App\Models\Animal::with(['species', 'breed', 'shelter'])->take(3)->get();
                    @endphp
                    
                    @foreach($animals as $animal)
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5>{{ $animal->name }}</h5>
                                <p class="text-muted">{{ $animal->description }}</p>
                                <small>
                                    <strong>Faj:</strong> {{ $animal->species->name }} | 
                                    <strong>Fajta:</strong> {{ $animal->breed->name }} | 
                                    <strong>Menhely:</strong> {{ $animal->shelter->name }}
                                </small>
                            </div>
                        </div>
                    @endforeach
                    
                    <div class="mt-4">
                        <h3>Különleges karakterek:</h3>
                        <p>€, £, ¥, ©, ®, ™, §, ¶, †, ‡, •, …</p>
                        <p>Emoji: 🐾 🐕 🐈 🐦 🐸 🐹 🐴</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
