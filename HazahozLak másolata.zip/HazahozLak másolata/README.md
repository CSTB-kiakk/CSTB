# HazaHozLak - Állat örökbefogadási platform

## Leírás

A HazaHozLak egy Laravel alapú webalkalmazás, amely összeköti a menhelyeket és a potenciális örökbefogadókat. Az alkalmazás lehetővé teszi a menhelyek számára, hogy feltöltsék az örökbefogadható állataikat, és a felhasználók számára, hogy böngészzenek az állatok között, szűrjenek kategóriák szerint, és kérjenek örökbefogadást.

## Funkciók

### Főbb funkciók
- 🏠 **Főoldal** - Bemutatkozás és kiemelt állatok
- 🐾 **Állataink** - Kategóriák szerinti böngészés és szűrés
- ℹ️ **Rólunk** - Az alkalmazás bemutatása
- 📞 **Kapcsolat** - Elérhetőségek és kapcsolati űrlap

### Állatok kezelése
- Kategóriák: Kutyák, Macskák, Hüllők és kétéltűek, Kisemlősök, Madarak, Lovak, Egyéb
- Részletes állat információk: név, faj, fajta, kor, leírás, kép
- Menhely információk: név, helyszín
- Szűrés kategóriák szerint
- Pagination támogatás

### Technikai jellemzők
- **Laravel 9.x** framework
- **Bootstrap 5** responsive design
- **Font Awesome** ikonok
- **MySQL** adatbázis
- **UTF-8** kódolás támogatás
- **Blade** templating engine

## Telepítés

### Előfeltételek
- PHP 8.0+
- Composer
- MySQL
- Web szerver (Apache/Nginx)

### Lépések

1. **Repository klónozása**
```bash
git clone https://github.com/CSTB-kiakk/CSTB.git
cd CSTB
```

2. **Függőségek telepítése**
```bash
composer install
```

3. **Környezeti változók beállítása**
```bash
cp .env.example .env
php artisan key:generate
```

4. **Adatbázis konfigurálása**
- Módosítsd a `.env` fájlban:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=hazahozlak
DB_USERNAME=root
DB_PASSWORD=
```

5. **Adatbázis importálása**
```bash
mysql -u root -p hazahozlak < public/hazahozlak.sql
```

6. **Alkalmazás indítása**
```bash
php artisan serve
```

Az alkalmazás elérhető lesz a `http://localhost:8000` címen.

## Adatbázis struktúra

### Táblák
- **animals** - Állatok adatai
- **shelters** - Menhelyek adatai
- **species** - Állatfajok
- **breeds** - Fajták
- **users** - Felhasználók
- **adoption_requests** - Örökbefogadási kérések
- **appointments** - Találkozók
- **donations** - Adományok

## Használat

### Menhelyek
1. Regisztrálj menhelyként
2. Töltsd fel az állataid adatait
3. Kezeld az örökbefogadási kéréseket

### Felhasználók
1. Böngészd az állatokat kategóriák szerint
2. Szűrj a keresési feltételek alapján
3. Kérj örökbefogadást kedvenc állatodért
4. Tartsd karban a kedvenceid listáját

## Fejlesztés

### Projekt struktúra
```
app/
├── Http/Controllers/     # Kontrollerek
├── Models/              # Eloquent modellek
resources/
├── views/               # Blade templatek
│   ├── layouts/         # Layout templatek
│   ├── animals/         # Állatok oldalak
│   └── auth/            # Autentikáció oldalak
public/
├── images/              # Képek
└── hazahozlak.sql       # Adatbázis dump
```

### Közreműködés
1. Fork-old a repository-t
2. Hozz létre egy feature branch-et
3. Commit-old a változtatásaidat
4. Push-old a branch-et
5. Hozz létre egy Pull Request-et

## Licenc

Ez a projekt MIT licenc alatt áll.

## Kapcsolat

Ha bármilyen kérdésed van, nyiss egy issue-t a GitHub-on vagy vedd fel a kapcsolatot velünk.

---

**Made with ❤️ for animals** 🐾