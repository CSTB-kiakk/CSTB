<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    /**
     * Bejelentkezési oldal megjelenítése
     */
    public function showLogin()
    {
        return view('auth.login');
    }

    /**
     * Bejelentkezés feldolgozása
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();
            
            return redirect()->intended(route('home'))
                ->with('success', 'Sikeresen bejelentkeztél!');
        }

        return back()->withErrors([
            'email' => 'A megadott adatok nem egyeznek a rendszerben tárolt adatokkal.',
        ])->onlyInput('email');
    }

    /**
     * Regisztrációs oldal megjelenítése
     */
    public function showRegister()
    {
        return view('auth.register');
    }

    /**
     * Regisztráció feldolgozása
     */
    public function register(Request $request)
    {
        $request->validate([
            'firstname' => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'email' => 'required|string|email|max:100|unique:users',
            'password' => ['required', 'confirmed', Password::defaults()],
        ]);

        $user = User::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'user'
        ]);

        Auth::login($user);

        return redirect()->route('home')
            ->with('success', 'Sikeresen regisztráltál és bejelentkeztél!');
    }

    /**
     * Kijelentkezés
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')
            ->with('success', 'Sikeresen kijelentkeztél!');
    }

    /**
     * Profil oldal megjelenítése
     */
    public function profile()
    {
        $user = auth()->user();
        return view('auth.profile', compact('user'));
    }

    /**
     * Profil frissítése
     */
    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'firstname' => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'email' => 'required|string|email|max:100|unique:users,email,' . $user->id,
        ]);

        $user->update($request->only(['firstname', 'lastname', 'email']));

        return redirect()->back()->with('success', 'Profil sikeresen frissítve!');
    }
}