<?php

namespace App\Http\Controllers;

use App\Models\Animal;
use App\Models\Species;
use App\Models\Breed;
use App\Models\Shelter;
use Illuminate\Http\Request;

class AnimalController extends Controller
{
    /**
     * Összes állat megjelenítése kategóriák szerint
     */
    public function index(Request $request)
    {
        $query = Animal::with(['species', 'breed', 'shelter'])
            ->where('status', 'Available');

        // Kategória szűrés
        if ($request->has('species') && $request->species) {
            $query->where('species_id', $request->species);
        }

        // Fajta szűrés
        if ($request->has('breed') && $request->breed) {
            $query->where('breed_id', $request->breed);
        }

        // Keresés név alapján
        if ($request->has('search') && $request->search) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $animals = $query->paginate(12);
        $species = Species::withCount('animals')->get();
        $breeds = Breed::with('species')->get();

        return view('animals.index', compact('animals', 'species', 'breeds'));
    }

    /**
     * Egy állat részletes megjelenítése
     */
    public function show($id)
    {
        $animal = Animal::with(['species', 'breed', 'shelter'])
            ->findOrFail($id);

        // Kapcsolódó állatok (ugyanaz a faj)
        $related_animals = Animal::with(['species', 'breed', 'shelter'])
            ->where('species_id', $animal->species_id)
            ->where('id', '!=', $animal->id)
            ->where('status', 'Available')
            ->take(4)
            ->get();

        return view('animals.show', compact('animal', 'related_animals'));
    }

    /**
     * Kategóriák oldal és állatok listázása
     */
    public function categories(Request $request)
    {
        // Összes faj lekérése
        $species = Species::withCount('animals')->get();
        
        // Állatok lekérése szűréssel
        $query = Animal::with(['species', 'breed', 'shelter'])
            ->where('status', 'Available');

        // Kategória szűrés
        if ($request->has('species') && $request->species) {
            $query->where('species_id', $request->species);
        }

        $animals = $query->paginate(12);
        $total_animals = Animal::where('status', 'Available')->count();
        
        return view('animals.categories', compact('species', 'animals', 'total_animals'));
    }

    /**
     * Kedvencek hozzáadása/eltávolítása
     */
    public function toggleFavorite(Request $request, $id)
    {
        if (!auth()->check()) {
            return response()->json(['error' => 'Be kell jelentkezned a kedvencek használatához'], 401);
        }

        $animal = Animal::findOrFail($id);
        $user = auth()->user();

        // Itt implementálnánk a kedvencek logikáját
        // Jelenleg csak egy egyszerű válasz

        return response()->json(['success' => true, 'message' => 'Kedvenc hozzáadva']);
    }

    /**
     * Örökbefogadási kérelem
     */
    public function adoptionRequest(Request $request, $id)
    {
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Be kell jelentkezned az örökbefogadási kérelemhez');
        }

        $request->validate([
            'message' => 'required|string|max:1000'
        ]);

        $animal = Animal::findOrFail($id);

        // Itt létrehoznánk az örökbefogadási kérelmet
        // \App\Models\AdoptionRequest::create([...]);

        return redirect()->back()->with('success', 'Örökbefogadási kérelem sikeresen elküldve!');
    }
}