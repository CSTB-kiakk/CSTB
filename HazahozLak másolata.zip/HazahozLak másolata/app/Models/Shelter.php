<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shelter extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'location',
        'contact_email',
        'description'
    ];

    public $timestamps = false;

    public function animals()
    {
        return $this->hasMany(Animal::class);
    }

    public function donations()
    {
        return $this->hasMany(Donation::class);
    }
}
